/**
 * Javascript to display a bus on the google map based on the data received from PAT
 */
var lon = -11.97;
var lat = 70.59;
var myCenter;
var myOtherCenter=new google.maps.LatLng(-11.97, 70.59);
var marker;
var map;
var infoWindow = new google.maps.InfoWindow();
var rt;
var dir;
var stopname;
//var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';

function initialize() {
    myCenter=new google.maps.LatLng(lat, lon);
    
    rt = getUrlParameter('rt');
    dir = getUrlParameter('dir');
    var mapProp = {
      center:myCenter,
      zoom:20,
      mapTypeId:google.maps.MapTypeId.ROADMAP
      };

    map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    var opt = { minZoom: 6, maxZoom: 20 };
    map.setOptions(opt);
    addMarker(myCenter, map, rt);
    
    showRoute();
    doInitialAjax();
    showStops();  
    setInterval(function(){
        doInitialAjax();
//        lon = lon + 0.001;
//        myCenter=new google.maps.LatLng(lat, lon);
//        moveMarker(marker, myCenter);
    }, 800);

}
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
    sURLVariables = sPageURL.split('&'),
    sParameterName,
    i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] === sParam) {
        return sParameterName[1] === undefined ? true : sParameterName[1];
    }
  }
};

function addMarker(location, map,rt) {
  marker = new google.maps.Marker({
    //position: location,
    center: location,
    //animation:google.maps.Animation.BOUNCE,
    title : "Bus",
      map: map,
      icon:   '622.png'
  });
  google.maps.event.addListener(marker, "click", (function(marker) {
      return function() {
        infoWindow.setContent(
          "<div>" + 
            "<span style='font-weight:bold;'>Bus: "+rt+"</span>" +
          "</div>"
        );
        infoWindow.open(map, marker);
      }    
    })(marker));
}


function addStopMarker(location, map,stopname) {
  var stop = new google.maps.Marker({
    position: location,
    //animation:google.maps.Animation.BOUNCE,
    
      map: map,
      icon:   'stopsign.png'
      //icon:   '622.png'
  });
  google.maps.event.addListener(stop, "click", (function(stop) {
      return function() {
        infoWindow.setContent(
          "<div>" + 
            "<span style='font-weight:bold;'>Stop: "+stopname+"</span>" +
          "</div>"
        );
        infoWindow.open(map, stop);
      }    
    })(stop));
}

function moveMarker(location) {  
        marker.setPosition(location);
        map.panTo(location);
};

function doInitialAjax() {
		
    jQuery.ajax(

        {
            crossDomain: true,
            url: "http://localhost:8080/Team2BusTracker/GetVehicles?rt="+rt+"&dir="+dir,
            dataType: "json",
            type: "GET", 
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
            },
            success: function(data, textStatus, jqXHR) {
                lat = data['bustime-response'].vehicle[0].lat;
                lon = data['bustime-response'].vehicle[0].lon;
                console.log(lat + lon);
                myCenter = new google.maps.LatLng(lat, lon);
                moveMarker(myCenter); 

            }
        }
    );
}
function showRoute() {
        
    jQuery.ajax(

        {
            crossDomain: true,
            url: "http://localhost:8080/Team2BusTracker/GetPatterns?rt="+rt+"&dir="+dir,
            dataType: "json",
            type: "GET", 
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
            },
            success: function(data, textStatus, jqXHR) {                
                
                var flightPlanCoordinates = [];
                    for(var i =0; i < data['bustime-response'].ptr[0].pt.length; i++){
                        flightPlanCoordinates.push(new google.maps.LatLng(data['bustime-response'].ptr[0].pt[i].lat, data['bustime-response'].ptr[0].pt[i].lon));
                    }
                    
            var flightPath = new google.maps.Polyline({
                
                path: flightPlanCoordinates,
                strokeColor: "#FF0000",
                strokeOpacity: 2.0,
                strokeWeight: 2
            }); 
            flightPath.setMap(map);
            }
        }
    );
}

function showStops() {
        
    jQuery.ajax(

        {
            crossDomain: true,
            url: "http://localhost:8080/Team2BusTracker/GetStops?rt="+rt+"&dir="+dir,
            dataType: "json",
            type: "GET", 
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
            },
            success: function(data, textStatus, jqXHR) {
                          
                
                var flightPlanCoordinates = [];
                    for(var i =0; i < data['bustime-response'].stops.length; i++){
                        //flightPlanCoordinates.push(new google.maps.LatLng(data['bustime-response'].stops[i].lat, data['bustime-response'].stops[i].lon));
                        addStopMarker(new google.maps.LatLng(data['bustime-response'].stops[i].lat, data['bustime-response'].stops[i].lon),map,data['bustime-response'].stops[i].stpnm);
                    }
    
            }
        }
    );
}

initialize();