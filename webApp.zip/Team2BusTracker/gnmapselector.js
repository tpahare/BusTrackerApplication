/**
 * Javascript to fetch coordinates from the source and destination enterd by the user.
 * Fetches the data from Google Map API and forwards it to the mapper.html page.
 */
var geocoder;
var globalvar = new Object();
var source = new Object();
var dest = new Object();

var getSource = true;
var getDest = false;

document.getElementById("submissionButton").addEventListener("click", function(){
    redirectToNext();
});

$(document).ready(function() {
 geocoder = new google.maps.Geocoder();
 $("#reminderBox").hide();
  $("#reminderChecker").click(function(event) {
    if ($(this).is(":checked"))
      $("#reminderBox").show();
    else
      $("#reminderBox").hide();
  });
});

function redirectToNext() {
    if (getSource == true && getDest == false) {
        getLatLongSource();    
    } else if (getSource == false && getDest == true) {
        getLatLongDes();
    } else {
        //change the url over here
        var nextPage = "mapper.html?sourceLat=" + source[0] + "&sourceLon=" + source[1] + "&destLat=" + dest[0] + "&destLon=" + dest[1];
        window.location = nextPage;
    }
}


function doInitialAjax(addressSome) {
    var stringComponents = addressSome.split(" ");
    var mainString = stringComponents[0];
    for (var i = 1; i < stringComponents.length; i++) {
        mainString = mainString.concat("+").concat(stringComponents[i]);
    }
    mainString = "https://maps.googleapis.com/maps/api/geocode/json?address=".concat(mainString).concat("&key=AIzaSyA2djLktf8QePVzSiAfhZyJWzM9BKT3eCI");
    console.log(mainString);
    jQuery.ajax(
        {
            crossDomain: true,
            url: mainString,
            dataType: "json",
            type: "GET", 
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus);
            },
            success: function(data, textStatus, jqXHR) {
              console.log(data);
              globalvar = [];
              globalvar[0] = data.results[0].geometry.location.lat;
              globalvar[1] = data.results[0].geometry.location.lng;
                
                if (getSource == true && getDest == false) {
                    source[0] = globalvar[0];
                    source[1] = globalvar[1];
                    getDest = true;
                    getSource = false;
                    redirectToNext();
                } else if (getSource == false && getDest == true) {
                    dest[0] = globalvar[0];
                    dest[1] = globalvar[1];
                    getDest = false;
                    redirectToNext();
                }
            }
        }
    );
}

var getLatLongSource = function() {
    var vals1 = new Object();
    var address1 = document.getElementById("source").value;
    doInitialAjax(address1);
}

var getLatLongDes = function() {
    var vals2 = new Object();
    var address2 = document.getElementById("destination").value;
    doInitialAjax(address2);
}




